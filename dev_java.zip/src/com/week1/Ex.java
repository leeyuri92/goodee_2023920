package com.week1;

public class Ex {
	String name;
	int ht;
	int cs;
	int js;
}
