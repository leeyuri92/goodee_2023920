package com.step2;

public class String1 {

	public static void main(String[] args) {
		String s1 = new String("키위");
		System.out.println(s1);
		s1 = new String("키위");
		System.out.println(s1);		
	}
}
/*
String타입은 클래스 이지만 마치 원시형 타입처럼 값이 출력됩니다.
주소번지를 볼 수 없어요
*/