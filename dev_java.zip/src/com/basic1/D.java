package com.basic1;
//D.java -> D.class, D1.class
class D1{
	//평균을 담을 변수 선언 - 말을 하고 그 다음에 낱말카드 적어보고 - 조립을 해나간다
	double avg = 0.0;
	int hap = 0;//총점을 담을 변수 선언
}

public class D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
