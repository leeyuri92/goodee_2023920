package com.step1;
// boolean은 true 혹은 false를 갖는다.
// 조건문이나 반복문에 사용됨
public class Boolean1 {
	
	public static void main(String[] args) {
		boolean isOK = false;		
		if(isOK) {
			System.out.println("괄호안에 조건식이 true일 때 실행됨");
		} else {
			System.out.println("거짓이면 여기로"); // 실행
		}
	}
}
