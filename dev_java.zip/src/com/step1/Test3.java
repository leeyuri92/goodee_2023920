package com.step1;

public class Test3 {	
	public static void main(String[] args) {
		P p=new P();
		System.out.println(P.i); 
		System.out.println(T.x); 
			}
}
/*
 static은 클래스 급이라서 인스턴스화 없이 호출이 가능하다
 
 */